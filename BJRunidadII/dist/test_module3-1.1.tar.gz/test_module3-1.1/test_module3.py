def cubo_area(a:float) ->float:
    A = 6.0*(a**2.0)
    return A

def cubo_vol(a:float) ->float:
    V = a**3.0
    return V