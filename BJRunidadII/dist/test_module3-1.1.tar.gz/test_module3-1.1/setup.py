from setuptools import setup

setup(
    name='test_module3',
    version='1.1',
    description='El programa calculara el area y el volumen de un cubo',
    author='JRB',
    author_email='jeanreynold.jrb@gmail.com',
    url='jeanreynold.jrb@gmail.com',
    py_modules=['test_module3'],

)